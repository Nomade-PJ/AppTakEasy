package com.br.financa;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }//Fim do OnCreate

    public void abrirCadastroReceita(View v){
        Intent it_receita =
                new Intent(this, ReceitaActivity.class);
        startActivity(it_receita);
    }

}//Fim da Classe
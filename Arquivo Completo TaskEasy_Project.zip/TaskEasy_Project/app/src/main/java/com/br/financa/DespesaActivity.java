package com.br.financa;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class DespesaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_despesa);

    }

}//Fim da Classe